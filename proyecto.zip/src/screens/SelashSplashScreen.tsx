import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';

export default function SelahSplashScreen(): React.JSX.Element {
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        // Animación de entrada (Fade In) para fundirse suavemente sobre el splash nativo
        Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
        }).start();
    }, [fadeAnim]);

    return (
        <View style={styles.container}>
            {/* 🎯 Usamos la imagen vertical completa que exportaste de Figma */}
            <Animated.Image
                source={require('../../assets/splash_screen.png')}
                style={[styles.splashImage, { opacity: fadeAnim }]}
                resizeMode="contain" // Mismo comportamiento de escalado que app.config.js
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121316', // El fondo oscuro idéntico al de tus diseños
        alignItems: 'center',
        justifyContent: 'center',
    },
    splashImage: {
        width: '100%',
        height: '100%',
    },
});
