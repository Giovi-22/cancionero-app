export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export type BandRole = 'owner' | 'director' | 'member';

export interface BandMember {
  userId: string;
  email: string;
  displayName: string;
  photoURL?: string | null;
  role: BandRole;
  invitationId?: string;
  joinedAt: string;
}

export interface Band {
  id: string;
  name: string;
  description?: string;
  ownerId: string;

  // Carpeta de Google Drive utilizada como fuente
  // de canciones para Band Mode.
  driveFolderId?: string;
  driveFolderName?: string;

  activeSessionId?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface BandSong {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: string;
  folderName?: string;
}

export type InvitationStatus = 'pending' | 'accepted' | 'rejected' | 'expired' | 'cancelled';

export interface Invitation {
  id: string;
  bandId: string;
  bandName: string;
  invitedEmail: string;
  invitedUserId?: string | null;
  invitedByUserId: string;
  invitedByName: string;
  role: BandRole;
  status: InvitationStatus;
  createdAt: string;
  expiresAt: string;
}

export type DirectorSessionStatus = 'active' | 'ended';

export interface DirectorSession {
  id: string;
  bandId: string;
  directorId: string;
  directorName: string;
  setlistId: string;
  setlistName: string;
  currentSongId?: string | null;
  status: DirectorSessionStatus;
  startedAt: string;
  createdAt: string;
  endedAt?: string | null;
}
export type DirectorEventType =
  | 'SONG_CHANGED'
  | 'SCROLL_UP'
  | 'SCROLL_DOWN'
  | 'SCROLL_POSITION';

export interface DirectorEvent {
  id?: string;
  type: DirectorEventType;
  senderId: string;
  payload?: {
    songId?: string;
    progress?: number;
    [key: string]: any;
  };
  timestamp: string;
}

export interface BandSetlist {
  id: string;
  bandId: string;
  name: string;
  date?: string;
  songIds: string[];
  notes?: string;
  songNotes?: Record<string, string>;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
