import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from 'react';
import { SongMetadata, Library, Setlist } from '../types';
import { firestore } from '../lib/firebase';
import { StorageService } from '../services/StorageService';
import { SyncService } from '../services/SyncService';
import { DriveService } from '../services/DriveService';
import { FileSystemService } from '../services/FileSystemService';
import { Alert, Keyboard } from 'react-native';
import { router } from 'expo-router';
import { useUserContext } from './UserContext';

export interface AppContextType {
  activeLibrary: Library | null;
  libraries: Library[];
  setActiveLibrary: (library: Library) => Promise<void>;
  songs: SongMetadata[];
  topSongs: SongMetadata[];
  setlists: Setlist[];
  isSyncing: boolean;
  // driveFolderId ya NO es un estado propio: se deriva siempre de
  // activeLibrary.driveFolderId para que nunca pueda desincronizarse
  // de la biblioteca activa (ver AppContextProvider).
  driveFolderId: string;
  loadingSongId: string | null;
  loadingActions: Record<string, boolean>;

  // Modals state
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isLibrariesOpen: boolean;
  setIsLibrariesOpen: (open: boolean) => void;
  isFolderPickerOpen: boolean;
  setIsFolderPickerOpen: (open: boolean) => void;
  isCreateSetlistOpen: boolean;
  setIsCreateSetlistOpen: (open: boolean) => void;
  isEditSetlistOpen: boolean;
  setIsEditSetlistOpen: (open: boolean) => void;

  // Folder Explorer state
  folders: any[];
  isLoadingFolders: boolean;
  setFolderPickerCallback: (cb: ((id: string, name: string) => void) | null) => void;
  navigationStack: any[];
  showShared: boolean;
  openFolderPicker: (
    parentId?: string,
    folderName?: string,
    shared?: boolean,
    onSelect?: (id: string, name: string) => void
  ) => Promise<void>;
  navigateBack: () => void;
  selectFolder: (id: string, name: string) => void;

  // Selected Viewer state
  selectedSong: SongMetadata | null;
  setSelectedSong: (song: SongMetadata | null) => void;
  songContent: string | null;
  setSongContent: (content: string | null) => void;
  songSettings: any;
  setSongSettings: (settings: any) => void;

  // Setlist view state
  activeSetlist: Setlist | null;
  setActiveSetlist: (setlist: Setlist | null) => void;
  setlistSongs: SongMetadata[];
  setSetlistSongs: (songs: SongMetadata[]) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Global Theme
  globalTheme: any;
  handleSaveGlobalTheme: (theme: any) => Promise<void>;

  handleStartSetlistLocally: (setlist: Setlist) => void;

  // Actions
  refreshLocalData: () => Promise<void>;
  handleSync: () => Promise<void>;
  handleSongPress: (song: SongMetadata) => Promise<void>;
  handleSaveSongSettings: (data: any) => Promise<void>;
  handleSaveConfig: (folderId: string) => Promise<void>;
  handleDeleteSetlist: (setlist: Setlist) => Promise<void>;
  handleCreateSetlist: (
    name: string,
    date?: Date,
    notes?: string
  ) => Promise<void>;
  handleRemoveSongFromSetlist: (songId: string) => Promise<void>;
  handleMoveSong: (fromIndex: number, toIndex: number) => Promise<void>;
  handleSaveSetlistSongs: (
    name: string,
    date: Date | undefined,
    songIds: string[],
    notes?: string
  ) => Promise<void>;
  handleUpdateSetlistNotes: (
    setlistId: string,
    notes: string
  ) => Promise<void>;
  handleUpdateSetlistSongNote: (
    setlistId: string,
    songId: string,
    note: string
  ) => Promise<void>;
  handleClearRepertoire: () => Promise<void>;

  // Library Actions
  handleCreateLibrary: (
    name: string,
    driveFolderId?: string,
    icon?: string,
    color?: string
  ) => Promise<void>;
  handleUpdateLibrary: (library: Library) => Promise<void>;
  handleDeleteLibrary: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppContextProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const { user } = useUserContext();

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLibrariesOpen, setIsLibrariesOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [loadingSongId, setLoadingSongId] = useState<string | null>(null);
  const [loadingActions, setLoadingActions] = useState<Record<string, boolean>>(
    {}
  );

  const startActionLoading = (actionName: string) => {
    setLoadingActions(prev => ({ ...prev, [actionName]: true }));
  };

  const stopActionLoading = (actionName: string) => {
    setLoadingActions(prev => ({ ...prev, [actionName]: false }));
  };

  // Bibliotecas
  const [libraries, setLibraries] = useState<Library[]>([]);
  const [activeLibrary, setActiveLibraryState] =
    useState<Library | null>(null);

  // driveFolderId se DERIVA de activeLibrary en cada render, en vez de
  // vivir en su propio useState. Antes existían dos fuentes de verdad
  // (activeLibrary.driveFolderId y un driveFolderId suelto) que se
  // desincronizaban cada vez que se agregaba un nuevo lugar que
  // actualizaba una sin actualizar la otra (ej: handleUpdateLibrary,
  // usado al editar una biblioteca desde "Administrar Bibliotecas").
  // Derivarlo elimina esa clase de bug por completo.
  const driveFolderId = activeLibrary?.driveFolderId || '';

  // Datos
  const [songs, setSongs] = useState<SongMetadata[]>([]);
  const [topSongs, setTopSongs] = useState<SongMetadata[]>([]);
  const [setlists, setSetlists] = useState<Setlist[]>([]);

  // Estado del Visor
  const [selectedSong, setSelectedSong] =
    useState<SongMetadata | null>(null);
  const [songContent, setSongContent] = useState<string | null>(null);
  const [songSettings, setSongSettings] = useState<any>(null);

  const [setlistSongs, setSetlistSongs] = useState<SongMetadata[]>([]);

  // Estado de Setlist Activa
  const [activeSetlist, setActiveSetlist] =
    useState<Setlist | null>(null);

  // Tema global
  const [globalTheme, setGlobalTheme] = useState<any>({
    background: '#0a0a0a',
    lyrics: '#ffffff',
    chords: '#3b82f6',
  });

  // Modals de creación / edición
  const [isCreateSetlistOpen, setIsCreateSetlistOpen] = useState(false);
  const [isEditSetlistOpen, setIsEditSetlistOpen] = useState(false);

  // Estado para el explorador de carpetas
  const [isFolderPickerOpen, setIsFolderPickerOpen] = useState(false);
  const [folderPickerCallback, setFolderPickerCallback] = useState<
    ((id: string, name: string) => void) | null
  >(null);
  const [folders, setFolders] = useState<any[]>([]);
  const [isLoadingFolders, setIsLoadingFolders] = useState(false);
  const [navigationStack, setNavigationStack] = useState<any[]>([
    { id: 'root', name: 'Mi unidad' },
  ]);
  const [showShared, setShowShared] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Inicialización de datos locales.
  //
  // La autenticación ahora pertenece exclusivamente a UserContext.
  useEffect(() => {
    loadInitialData();
  }, []);

  // Limpiar buscador al cambiar de lista
  useEffect(() => {
    setSearchQuery('');
  }, [activeSetlist]);

  /**
   * Si el usuario o la biblioteca activa cambian, intentamos
   * iniciar la sincronización de fondo cuando corresponde.
   *
   * Esto evita depender del momento exacto en que Firebase
   * termina de resolver la sesión.
   */
  useEffect(() => {
    if (!user || !activeLibrary?.driveFolderId) return;

    triggerBackgroundSync(
      activeLibrary.driveFolderId,
      activeLibrary.id
    );
  }, [user, activeLibrary?.id]);

  const loadInitialData = async () => {
    try {
      // Cargar bibliotecas desde DB
      const allLibraries = await StorageService.getAllLibraries();
      setLibraries(allLibraries);

      // Obtener biblioteca activa
      const savedLibId =
        await StorageService.getSetting<string>('active_library_id');

      const activeLib =
        allLibraries.find(l => l.id === savedLibId) ||
        allLibraries.find(l => l.id === 'default') ||
        allLibraries[0] ||
        null;

      setActiveLibraryState(activeLib);

      if (activeLib) {
        await refreshLocalDataForLibrary(activeLib.id);
      }

      // Cargar tema global
      const savedGlobalTheme =
        await StorageService.getSetting<any>('global_theme');

      if (savedGlobalTheme) {
        setGlobalTheme(savedGlobalTheme);
      }
    } catch (e) {
      console.error('Error loading initial local data:', e);
    }
  };

  const refreshLocalDataForLibrary = async (libId: string) => {
    const localSongs = await StorageService.getAllSongs(libId);
    setSongs(localSongs);

    const top = await StorageService.getTopSongs(5, libId);
    setTopSongs(top);

    const localSetlists =
      await StorageService.getAllSetlists(libId);
    setSetlists(localSetlists);
  };

  const refreshLocalData = async () => {
    if (activeLibrary) {
      await refreshLocalDataForLibrary(activeLibrary.id);
    }
  };

  const setActiveLibrary = async (library: Library) => {
    startActionLoading('setActiveLibrary');

    try {
      setActiveLibraryState(library);

      await StorageService.saveSetting(
        'active_library_id',
        library.id
      );

      // Cerrar setlists y buscador para limpiar el contexto visual
      setActiveSetlist(null);

      await refreshLocalDataForLibrary(library.id);

      if (library.driveFolderId && user) {
        triggerBackgroundSync(
          library.driveFolderId,
          library.id
        );
      }
    } catch (e) {
      console.error('Error setting active library:', e);
    } finally {
      stopActionLoading('setActiveLibrary');
    }
  };

  const triggerBackgroundSync = async (
    folderId: string,
    libId: string
  ) => {
    try {
      const didChange =
        await SyncService.syncFullRepertoire(
          folderId,
          false,
          libId
        );

      if (didChange) {
        await refreshLocalDataForLibrary(libId);
      }
    } catch (error) {
      console.warn(
        '[AppContext] Background sync error:',
        error
      );
    }
  };

  const handleSync = async () => {
    if (isSyncing || !activeLibrary) return;

    setIsSyncing(true);

    try {
      await SyncService.syncFullRepertoire(
        activeLibrary.driveFolderId || '',
        false,
        activeLibrary.id
      );

      await refreshLocalDataForLibrary(activeLibrary.id);

      Alert.alert(
        'Éxito',
        'Sincronización completada'
      );
    } catch (error) {
      console.error('Sync error:', error);

      Alert.alert(
        'Error',
        'No se pudo sincronizar: ' +
        (error as any).message
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSongPress = async (song: SongMetadata) => {
    if (loadingSongId) return;

    setLoadingSongId(song.id);

    try {
      const content =
        await FileSystemService.getSongContent(song.id);

      if (!content) {
        Alert.alert(
          'Error',
          'No se encontró el contenido de la canción. Intenta sincronizar de nuevo.'
        );
        return;
      }

      await StorageService.incrementSongViewCount(song.id);

      // Cargar configuraciones específicas de esta biblioteca
      const libId =
        activeLibrary?.id || 'default';

      let settings =
        await StorageService.getSetting(
          `song_settings_${libId}_${song.id}`
        );

      // Fallback a configuración anterior global si es la de por defecto
      if (!settings && libId === 'default') {
        settings =
          await StorageService.getSetting(
            `song_settings_${song.id}`
          );
      }

      setSongContent(content);
      setSongSettings(settings);
      setSelectedSong(song);

      await refreshLocalDataForLibrary(libId);

      router.push({
        pathname: '/song/[id]',
        params: { id: song.id },
      } as any);
    } catch (error) {
      Alert.alert(
        'Error',
        'No se pudo abrir la canción.'
      );
    } finally {
      setLoadingSongId(null);
    }
  };

  // Navegar a una canción sin añadir al stack
  const handleNavigateToSong = async (
    song: SongMetadata
  ) => {
    try {
      const content =
        await FileSystemService.getSongContent(song.id);

      if (!content) {
        Alert.alert(
          'Error',
          'No se encontró el contenido de la canción.'
        );
        return;
      }

      await StorageService.incrementSongViewCount(
        song.id
      );

      const libId =
        activeLibrary?.id || 'default';

      let settings =
        await StorageService.getSetting(
          `song_settings_${libId}_${song.id}`
        );

      if (!settings && libId === 'default') {
        settings =
          await StorageService.getSetting(
            `song_settings_${song.id}`
          );
      }

      setSongContent(content);
      setSongSettings(settings);
      setSelectedSong(song);

      router.replace(`/song/${song.id}`);
    } catch (error) {
      Alert.alert(
        'Error',
        'No se pudo cambiar la canción.'
      );
    }
  };

  const handleSaveSongSettings = async (
    data: any
  ) => {
    if (
      data &&
      data.songId &&
      data.settings
    ) {
      const libId =
        activeLibrary?.id || 'default';

      await StorageService.saveSetting(
        `song_settings_${libId}_${data.songId}`,
        data.settings
      );
    }
  };

  const handleSaveGlobalTheme = async (
    theme: any
  ) => {
    setGlobalTheme(theme);

    await StorageService.saveSetting(
      'global_theme',
      theme
    );
  };

  const handleSaveConfig = async (
    newFolderId: string
  ) => {
    if (activeLibrary) {
      const updated = {
        ...activeLibrary,
        driveFolderId: newFolderId,
        updatedAt: Date.now(),
      };

      await StorageService.saveLibrary(updated);

      setActiveLibraryState(updated);

      setLibraries(prev =>
        prev.map(l =>
          l.id === updated.id
            ? updated
            : l
        )
      );
    }
  };

  const handleDeleteSetlist = async (
    setlist: Setlist
  ) => {
    startActionLoading(
      `deleteSetlist_${setlist.id}`
    );

    try {
      await StorageService.deleteSetlistLocal(
        setlist.id
      );

      await refreshLocalData();
    } finally {
      stopActionLoading(
        `deleteSetlist_${setlist.id}`
      );
    }
  };

  const formatDate = (
    isoString: string
  ) => {
    const d = new Date(isoString);

    const day = d
      .getDate()
      .toString()
      .padStart(2, '0');

    const month = (d.getMonth() + 1)
      .toString()
      .padStart(2, '0');

    const year = d
      .getFullYear()
      .toString()
      .slice(-2);

    return `${day}/${month}/${year}`;
  };

  const handleCreateSetlist = async (
    name: string,
    date?: Date,
    notes?: string
  ) => {
    if (!activeLibrary) {
      Alert.alert(
        'Biblioteca no seleccionada',
        'Debes seleccionar una biblioteca antes de crear una lista.'
      );
      return;
    }

    const trimmed = name.trim();

    if (!trimmed) {
      Alert.alert('Error', 'El nombre de la lista no puede estar vacío.');
      return;
    }

    const dateStr = date
      ? formatDate(date.toISOString())
      : null;

    const finalName = dateStr
      ? `${trimmed} - ${dateStr}`
      : trimmed;

    const newSetlist: Setlist = {
      id: `local_${Date.now()}`,
      name: finalName,
      date: date
        ? date.toISOString()
        : undefined,
      songIds: [],
      isPublic: false,
      notes: notes?.trim() || undefined,
      libraryId: activeLibrary.id,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(newSetlist);

    await refreshLocalData();

    setIsCreateSetlistOpen(false);
    Keyboard.dismiss();
  };

  const handleRemoveSongFromSetlist = async (
    songId: string
  ) => {
    if (!activeSetlist) {
      return;
    }

    const newSongIds =
      activeSetlist.songIds.filter(
        id => id !== songId
      );

    const updated: Setlist = {
      ...activeSetlist,
      songIds: newSongIds,
      libraryId: activeSetlist.libraryId,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(updated);

    setActiveSetlist(updated);

    await refreshLocalData();
  };

  const handleMoveSong = async (
    fromIndex: number,
    toIndex: number
  ) => {
    if (!activeSetlist) {
      return;
    }

    const newSongIds = [
      ...activeSetlist.songIds,
    ];

    const [movedId] =
      newSongIds.splice(
        fromIndex,
        1
      );

    newSongIds.splice(
      toIndex,
      0,
      movedId
    );

    const updated: Setlist = {
      ...activeSetlist,
      songIds: newSongIds,
      libraryId: activeSetlist.libraryId,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(updated);

    setActiveSetlist(updated);

    await refreshLocalData();
  };

  const handleSaveSetlistSongs = async (
    name: string,
    date: Date | undefined,
    songIds: string[],
    notes?: string
  ) => {
    if (!activeSetlist) {
      return;
    }

    // Validar que todas las canciones pertenezcan a la biblioteca del setlist
    const librarySongs = await StorageService.getAllSongs(activeSetlist.libraryId);
    const validSongIds = new Set(librarySongs.map(s => s.id));

    const hasForeignSong = songIds.some(id => !validSongIds.has(id));
    if (hasForeignSong) {
      Alert.alert(
        'Canción inválida',
        'Una o más canciones seleccionadas no pertenecen a la biblioteca de esta lista.'
      );
      return;
    }

    const cleanName =
      name.trim().split(' - ')[0];

    const dateStr = date
      ? formatDate(date.toISOString())
      : null;

    const finalName = dateStr
      ? `${cleanName} - ${dateStr}`
      : cleanName;

    const updated: Setlist = {
      ...activeSetlist,
      name: finalName,
      date: date
        ? date.toISOString()
        : undefined,
      songIds,
      libraryId: activeSetlist.libraryId,
      notes:
        notes !== undefined
          ? notes
          : activeSetlist.notes,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(updated);

    setActiveSetlist(updated);

    setSetlists(prev =>
      prev.map(s =>
        s.id === updated.id
          ? updated
          : s
      )
    );

    setIsEditSetlistOpen(false);

    await refreshLocalData();
  };

  const handleUpdateSetlistNotes = async (
    setlistId: string,
    notes: string
  ) => {
    const targetSetlist =
      setlists.find(
        s => s.id === setlistId
      ) ||
      (activeSetlist?.id === setlistId
        ? activeSetlist
        : null);

    if (!targetSetlist) {
      return;
    }

    const updated: Setlist = {
      ...targetSetlist,
      notes,
      libraryId: targetSetlist.libraryId,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(updated);

    if (
      activeSetlist?.id === setlistId
    ) {
      setActiveSetlist(updated);
    }

    setSetlists(prev =>
      prev.map(s =>
        s.id === setlistId
          ? updated
          : s
      )
    );
  };

  const handleUpdateSetlistSongNote = async (
    setlistId: string,
    songId: string,
    note: string
  ) => {
    const targetSetlist =
      setlists.find(
        s => s.id === setlistId
      ) ||
      (activeSetlist?.id === setlistId
        ? activeSetlist
        : null);

    if (!targetSetlist) {
      return;
    }

    const currentNotes = {
      ...(targetSetlist.songNotes || {}),
    };

    const trimmed = note.trim();

    if (trimmed) {
      currentNotes[songId] =
        trimmed;
    } else {
      delete currentNotes[songId];
    }

    const updated: Setlist = {
      ...targetSetlist,
      songNotes: currentNotes,
      libraryId: targetSetlist.libraryId,
      lastUpdated: new Date().toISOString(),
    };

    await StorageService.saveSetlist(updated);

    if (
      activeSetlist?.id === setlistId
    ) {
      setActiveSetlist(updated);
    }

    setSetlists(prev =>
      prev.map(s =>
        s.id === setlistId
          ? updated
          : s
      )
    );
  };

  const handleClearRepertoire = async () => {
    if (!activeLibrary) return;

    try {
      setIsSyncing(true);

      // 1. Obtener todas las canciones locales
      const localSongs =
        await StorageService.getAllSongs(
          activeLibrary.id
        );

      // 2. Borrar archivos físicos
      for (const song of localSongs) {
        await FileSystemService.deleteSongFile(
          song.id
        );
      }

      // 3. Borrar registros de la base de datos local
      const db =
        await StorageService.getDb();

      await db.runAsync(
        'DELETE FROM songs WHERE library_id = ?',
        [activeLibrary.id]
      );

      // 4. Borrar estadísticas en Firestore si está autenticado
      if (user) {
        try {
          const userId =
            user.id || user.uid;

          const snapshot =
            await firestore()
              .collection('song_stats')
              .where(
                'user_id',
                '==',
                userId
              )
              .get();

          const batch =
            firestore().batch();

          snapshot.docs.forEach(
            (doc: any) =>
              batch.delete(doc.ref)
          );

          await batch.commit();
        } catch (error) {
          console.error(
            '[Clear Repertoire] Error clearing Firestore stats:',
            error
          );
        }
      }

      // 5. Recargar datos locales
      await refreshLocalDataForLibrary(
        activeLibrary.id
      );

      Alert.alert(
        'Éxito',
        'Se limpiaron todas las canciones locales y sus estadísticas.'
      );
    } catch (e) {
      console.error(
        '[Clear Repertoire] Error clearing songs:',
        e
      );

      Alert.alert(
        'Error',
        'No se pudieron limpiar las canciones.'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  // --- CRUD de Bibliotecas ---

  const handleCreateLibrary = async (
    name: string,
    folderId?: string,
    icon?: string,
    color?: string
  ) => {
    const now = Date.now();

    const newLib: Library = {
      id: `lib_${now}`,
      name: name.trim(),
      driveFolderId: folderId || '',
      syncEnabled: true,
      icon: icon || 'book-open',
      color: color || '#3b82f6',
      createdAt: now,
      updatedAt: now,
    };

    await StorageService.saveLibrary(
      newLib
    );

    const all =
      await StorageService.getAllLibraries();

    setLibraries(all);

    // Cambiar automáticamente a la nueva biblioteca
    await setActiveLibrary(newLib);
  };

  const handleUpdateLibrary = async (
    library: Library
  ) => {
    const updated = {
      ...library,
      updatedAt: Date.now(),
    };

    await StorageService.saveLibrary(
      updated
    );

    const all =
      await StorageService.getAllLibraries();

    setLibraries(all);

    if (
      activeLibrary &&
      activeLibrary.id === library.id
    ) {
      setActiveLibraryState(updated);
    }
  };

  const handleDeleteLibrary = async (
    id: string
  ) => {
    if (id === 'default') {
      Alert.alert(
        'Error',
        'No puedes eliminar la biblioteca principal.'
      );
      return;
    }

    Alert.alert(
      'Eliminar Biblioteca',
      '¿Estás seguro? Esto eliminará localmente las canciones y listas de esta biblioteca.',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: async () => {
            await StorageService.deleteLibrary(
              id
            );

            const all =
              await StorageService.getAllLibraries();

            setLibraries(all);

            // Si eliminamos la activa, volvemos a la default
            if (
              activeLibrary &&
              activeLibrary.id === id
            ) {
              const def =
                all.find(
                  l => l.id === 'default'
                ) || all[0];

              if (def) {
                await setActiveLibrary(
                  def
                );
              }
            }
          },
        },
      ]
    );
  };

  //Personal setlist helper
  const handleStartSetlistLocally = (
    setlist: Setlist
  ) => {
    const songsOfList =
      setlist.songIds
        .map(id =>
          songs.find(
            s => s.id === id
          )
        )
        .filter(Boolean) as SongMetadata[];

    setSetlistSongs(songsOfList);

    if (songsOfList.length > 0) {
      router.push({
        pathname:
          '/setlist-player/[setlistId]',
        params: {
          setlistId: setlist.id,
        },
      } as any);
    } else {
      Alert.alert(
        'Lista vacía',
        'Agrega canciones a la lista para poder iniciarla.'
      );
    }
  };


  // Lógica del Explorador de Carpetas Drive

  const openFolderPicker = async (
    parentId: string = 'root',
    folderName: string = 'Mi unidad',
    shared: boolean = false,
    onSelect?: (id: string, name: string) => void
  ) => {
    if (onSelect) {
      setFolderPickerCallback(
        () => onSelect
      );
    }

    setIsLoadingFolders(true);
    setIsFolderPickerOpen(true);
    setShowShared(shared);

    try {
      const folderList =
        await DriveService.listFolders(
          parentId,
          shared
        );

      setFolders(folderList);

      if (parentId === 'root') {
        setNavigationStack([
          {
            id: 'root',
            name: shared
              ? 'Compartidos'
              : 'Mi unidad',
          },
        ]);
      } else {
        setNavigationStack([
          ...navigationStack,
          {
            id: parentId,
            name: folderName,
          },
        ]);
      }
    } catch (error: any) {
      console.error(
        '[AppContext] Error en openFolderPicker:',
        error
      );

      Alert.alert(
        'Error al acceder a Drive',
        error?.message ||
        'No se pudieron cargar las carpetas de Drive. Por favor, verifica tu conexión o intenta volver a iniciar sesión.'
      );
    } finally {
      setIsLoadingFolders(false);
    }
  };

  const navigateBack = () => {
    if (
      navigationStack.length <= 1
    ) {
      return;
    }

    const newStack = [
      ...navigationStack,
    ];

    newStack.pop();

    const prevFolder =
      newStack[
      newStack.length - 1
      ];

    setNavigationStack(newStack);

    openFolderPicker(
      prevFolder.id,
      prevFolder.name,
      showShared
    );
  };

  const selectFolder = (id: string, name: string) => {
    if (folderPickerCallback) {
      folderPickerCallback(id, name);
    } else {
      handleSaveConfig(id);
    }

    setIsFolderPickerOpen(false);
    setFolderPickerCallback(null);
    Keyboard.dismiss();
  };
  return (
    <AppContext.Provider
      value={{
        activeLibrary,
        libraries,
        setActiveLibrary,
        songs,
        topSongs,
        setlists,
        isSyncing,
        driveFolderId,
        isSettingsOpen,
        setIsSettingsOpen,
        isLibrariesOpen,
        setIsLibrariesOpen,
        isFolderPickerOpen,
        setIsFolderPickerOpen,
        isCreateSetlistOpen,
        setIsCreateSetlistOpen,
        isEditSetlistOpen,
        setIsEditSetlistOpen,
        loadingSongId,
        loadingActions,
        folders,
        isLoadingFolders,
        navigationStack,
        showShared,
        openFolderPicker,
        navigateBack,
        selectFolder,
        setFolderPickerCallback,
        selectedSong,
        setSelectedSong,
        songContent,
        setSongContent,
        songSettings,
        setSongSettings,
        activeSetlist,
        setActiveSetlist,
        setlistSongs,
        setSetlistSongs,
        searchQuery,
        setSearchQuery,
        globalTheme,
        handleSaveGlobalTheme,
        handleStartSetlistLocally,
        refreshLocalData,
        handleSync,
        handleSongPress,
        handleSaveSongSettings,
        handleSaveConfig,
        handleDeleteSetlist,
        handleCreateSetlist,
        handleRemoveSongFromSetlist,
        handleMoveSong,
        handleSaveSetlistSongs,
        handleUpdateSetlistNotes,
        handleUpdateSetlistSongNote,
        handleCreateLibrary,
        handleUpdateLibrary,
        handleDeleteLibrary,
        handleClearRepertoire,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);

  if (!context) {
    throw new Error(
      'useAppContext must be used within an AppContextProvider'
    );
  }

  return context;
};
